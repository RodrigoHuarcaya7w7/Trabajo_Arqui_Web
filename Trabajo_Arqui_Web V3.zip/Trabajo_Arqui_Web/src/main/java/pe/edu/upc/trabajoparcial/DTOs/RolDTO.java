package pe.edu.upc.trabajoparcial.DTOs;

import lombok.Data;

@Data
public class RolDTO {

    private Integer idRol;
    private String rol;


    // Constructor, getters y setters si es necesario
}