package pe.edu.upc.trabajoparcial.DTOs;

import lombok.Data;

@Data
public class TipoPagoDTO {

    private Integer idTipoPago;
    private String nombrePago;

}