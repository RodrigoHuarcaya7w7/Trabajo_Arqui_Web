package pe.edu.upc.trabajoparcial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoparcialApplication {

	public static void main(String[] args) {

		SpringApplication.run(TrabajoparcialApplication.class, args);
	}

}
