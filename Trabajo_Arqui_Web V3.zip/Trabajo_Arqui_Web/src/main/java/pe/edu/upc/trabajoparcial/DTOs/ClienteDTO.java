package pe.edu.upc.trabajoparcial.DTOs;

import lombok.Data;

@Data
public class ClienteDTO {

    private Integer idCliente;
    private Integer idUsuario;

    // Constructor, getters y setters si es necesario
}