package pe.edu.upc.trabajoparcial.DTOs;


import lombok.Data;

@Data
public class CategoriaDTO {

    private Integer idCategoria;
    private String nombre;
    private String descripcion;

}